<?php
include_once __DIR__ . '/../../app/koneksi.php';
$koneksi = $mysqli;

$data_cek = null;

$redirectPage = "http://localhost/simkbs/data_kependudukan"; // default
if (isset($_GET['from'])) {
  if ($_GET['from'] === 'anggota_kk' && isset($_GET['kode'])) {
    $redirectPage = 'index.php?page=anggota_kk&kode=' . $_GET['kode'];
  }
}

if (isset($_POST['Ubah'])) {
  $sql_ubah = "UPDATE tabel_kependudukan SET 
    NIK = '" . $_POST['NIK'] . "',
    NO_KK = '" . $_POST['NO_KK'] . "',
    NAMA_LGKP = '" . $_POST['NAMA_LGKP'] . "',
    HBKEL = '" . $_POST['HBKEL'] . "',
    JK = '" . $_POST['JK'] . "',
    DSN = '" . $_POST['DSN'] . "',
    KECAMATAN = '" . $_POST['KECAMATAN'] . "',
    KELURAHAN = '" . $_POST['KELURAHAN'] . "'
    WHERE NIK = '" . $_POST['NIK'] . "'";

  $query_ubah = mysqli_query($koneksi, $sql_ubah);
  mysqli_close($koneksi);

  if ($query_ubah) {
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
    echo "<script>
    Swal.fire({
    title: '✅ Berhasil!',
    text: 'Data berhasil diubah.',
    icon: 'success',
    confirmButtonText: 'OK'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = '$redirectPage';
    }
  });
  </script>";
  exit;
  } else {
    echo "<script>
      Swal.fire({
        title: '❌ Gagal Mengubah Data!',
        text: 'Periksa koneksi atau data input.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    </script>";
  }
}

if (isset($_GET['nik'])) {
  $nik = $_GET['nik'];
  $sql_cek = "SELECT * FROM tabel_kependudukan WHERE NIK = '$nik'";
  $query_cek = mysqli_query($koneksi, $sql_cek);
  $data_cek = mysqli_fetch_array($query_cek, MYSQLI_BOTH);
}

// Validasi jika data tidak ditemukan
if (!$data_cek) {
  echo "<script>
    alert('Data tidak ditemukan!');
    window.location.href = 'http://localhost/simkbs/data_kependudukan';
  </script>";
  exit;
}
?>

<div class="card card-success mt-5">
  <div class="card-header">
    <h3 class="card-title">
      <i class="fa fa-edit"></i> Ubah Data KK
    </h3>
  </div>

  <form action="" method="post">
    <div class="card-body">
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">NIK</label>
        <div class="col-sm-4">
          <input type="text" class="form-control" name="NIK" value="<?= $data_cek['NIK'] ?? '' ?>" readonly>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-2 col-form-label">No KK</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="NO_KK" value="<?= $data_cek['NO_KK'] ?? '' ?>" required>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Nama</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="NAMA_LGKP" value="<?= $data_cek['NAMA_LGKP'] ?? '' ?>" required>
        </div>
      </div>

      <!-- <div class="form-group row">
        <label class="col-sm-2 col-form-label">Hubungan Keluarga</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="HBKEL" value="<?= $data_cek['HBKEL'] ?? '' ?>" required>
        </div>
      </div> -->

      <div class="form-group row">
  <label class="col-sm-2 col-form-label">Hubungan Keluarga</label>
  <div class="col-sm-6">
    <select class="form-control select2" name="HBKEL" required>
      <option hidden value="">--Pilih Hubungan Keluarga--</option>
      <option value="1" <?= ($data_cek['HBKEL'] ?? '') == 1 ? 'selected' : '' ?>>Kepala Keluarga</option>
      <option value="2" <?= ($data_cek['HBKEL'] ?? '') == 2 ? 'selected' : '' ?>>Istri</option>
      <option value="3" <?= ($data_cek['HBKEL'] ?? '') == 3 ? 'selected' : '' ?>>Anak</option>
      <option value="4" <?= ($data_cek['HBKEL'] ?? '') == 4 ? 'selected' : '' ?>>Kakek</option>
      <option value="5" <?= ($data_cek['HBKEL'] ?? '') == 5 ? 'selected' : '' ?>>Nenek</option>
      <option value="6" <?= ($data_cek['HBKEL'] ?? '') == 6 ? 'selected' : '' ?>>Family Lain</option>
    </select>
  </div>
</div>

      <!-- <div class="form-group row">
        <label class="col-sm-2 col-form-label">Jenis Kelamin</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="JK" value="<?= $data_cek['JK'] ?? '' ?>" required>
        </div>
      </div> -->

      <div class="form-group row">
  <label class="col-sm-2 col-form-label">Jenis Kelamin</label>
  <div class="col-sm-6">
    <select class="form-control select2" name="JK" required>
      <option hidden value="">--Pilih Jenis Kelamin--</option>
      <option value="1" <?= ($data_cek['JK'] ?? '') == 1 ? 'selected' : '' ?>>Laki-laki</option>
      <option value="2" <?= ($data_cek['JK'] ?? '') == 2 ? 'selected' : '' ?>>Perempuan</option>
    </select>
  </div>
</div>


      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Desa</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="DSN" value="<?= $data_cek['DSN'] ?? '' ?>" required>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Kecamatan</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="KECAMATAN" value="<?= $data_cek['KECAMATAN'] ?? '' ?>" required>
        </div>
      </div>

      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Kelurahan</label>
        <div class="col-sm-6">
          <input type="text" class="form-control" name="KELURAHAN" value="<?= $data_cek['KELURAHAN'] ?? '' ?>" required>
        </div>
      </div>

    <div class="card-footer">
      <button type="submit" name="Ubah" class="btn btn-success">
        <i class="fa fa-save"></i> Simpan Perubahan
      </button>
      <a href="<?= $redirectPage ?>" class="btn btn-secondary">Batal</a>
    </div>
  </form>
</div>